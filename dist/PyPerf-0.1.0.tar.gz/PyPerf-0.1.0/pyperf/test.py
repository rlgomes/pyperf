import perf
import time
import random

random.seed(time.time())

@perf.measure
def somefunction():
    time.sleep(random.random()*0.01)
    return 0

@perf.measure
def somefunction2():
    time.sleep(random.random()*0.01)
    return 0

for i in range(0,1000):
    if random.randrange(0,2) == 1:
        somefunction()
    else:
        somefunction2()
        