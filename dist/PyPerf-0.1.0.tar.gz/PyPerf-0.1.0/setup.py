from distutils.core import setup

setup(
    name='PyPerf',
    version='0.1.0',
    author='Rodney Gomes',
    author_email='rodneygomes@gmail.com',
    packages=['pyperf'],
    scripts=[],
    url='',
    license='LICENSE',
    description='',
    long_description=open('README').read(),
)