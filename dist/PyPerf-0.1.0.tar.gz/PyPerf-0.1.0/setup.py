from distutils.core import setup

setup (
    name='PyPerf',
    version='0.1.0',
    author='Rodney Gomes',
    author_email='rodneygomes@gmail.com',
    packages = ['pyperf'],
    url='',
    license='Apache 2.0 License',
    description='',
    long_description=open('README').read(),
)